/* change the image */
function change(picture) {
    document.getElementById("large").src = picture;
    alert("here");
}